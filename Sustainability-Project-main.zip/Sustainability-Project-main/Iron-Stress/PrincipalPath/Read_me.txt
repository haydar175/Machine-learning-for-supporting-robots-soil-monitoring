Select the starting and end point as follows: 
1- starting point: extreme right 
2- ending point: extreme left 
from itertools import combinations
import numpy as np
import os
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt
from openTSNE import TSNE
import sys

# Add PrincipalPath package to path
sys.path.append('C:/Users/halhajali/OneDrive - Fondazione Istituto Italiano Tecnologia/Desktop/IIT-UNIBZ/PrincipalPath-master/PrincipalPath-master')
import linear_utilities as lu
import principalpath as pp

def load_data(base_path):
    conditions = ["Early", "Control", "Late"]
    plants = ["plant3", "plant0", "plant1"]
   # indices = [198, 199, 187]
    indices = [0, 1, 2, 3]
    all_data, data_labels, plant_ids = [], [], []

    for condition in conditions:
        for plant in plants:
            folder_path = os.path.join(base_path, condition, plant)
            if not os.path.exists(folder_path): continue
            for file_name in os.listdir(folder_path):
                if not file_name.endswith('.csv'): continue
                file_path = os.path.join(folder_path, file_name)
                try:
                    data = np.genfromtxt(file_path, delimiter=',')
                    if data.shape[0] >= 3 and data.shape[1] >= 5:
                        flattened = data[indices, 3:5].flatten()
                        all_data.append(flattened)
                        data_labels.append(condition)
                        plant_ids.append(plant)
                except Exception as e:
                    print(f"Error loading {file_path}: {e}")
                    continue
    return np.array(all_data), np.array(data_labels), np.array(plant_ids)

# Main
base_path = "C:/Users/halhajali/OneDrive - Fondazione Istituto Italiano Tecnologia/Desktop/IIT-UNIBZ/Dataset/Water-Stress/"
X_raw, labels, plant_ids = load_data(base_path)

plant_list = ["plant3", "plant0", "plant1"]
condition_colors = {'Early': 'blue', 'Control': 'red', 'Late': 'green'}

for idx, test_plant in enumerate(plant_list):
    if test_plant in ['plant0', 'plant3']:
        continue
    train_plants = [p for p in plant_list if p != test_plant]
    print(f"\nFold {idx + 1}:")
    print(f"Train: {train_plants}, Test: {test_plant}")

    train_mask = np.isin(plant_ids, train_plants)
    test_mask = (plant_ids == test_plant)

    scaler = MinMaxScaler()
    X_train_raw = X_raw[train_mask]
    X_test_raw = X_raw[test_mask]
    X_train = scaler.fit_transform(X_train_raw)
    X_test = scaler.transform(X_test_raw)

    X = np.zeros_like(X_raw)
    X[train_mask] = X_train
    X[test_mask] = X_test

    labels_train, labels_test = labels[train_mask], labels[test_mask]
    boundary_ids = lu.getMouseSamples2D(X_train, 2)
    NC = 7
    waypoint_ids = lu.initMedoids(X_train, NC, 'kpp', boundary_ids)
    waypoint_ids = np.hstack([boundary_ids[0], waypoint_ids, boundary_ids[1]])
    W_init = X_train[waypoint_ids, :]

    s_span = np.hstack([np.logspace(5, -5), 0])
    models = np.zeros([s_span.size, NC + 2, X.shape[1]])
    for i, s in enumerate(s_span):
        W, _ = pp.rkm(X_train, W_init, s, plot_ax=None)
        W_init = W
        models[i, :, :] = W
    best_s_id = np.argmax(pp.rkm_MS_evidence(models, s_span, X_train))
    W_path = models[best_s_id, :, :]
    print(f"t-SNE fitting on the first training plant: {train_plants[0]}")
    first_train_plant = train_plants[0]
    second_train_plant = train_plants[1]

    mask_train_plant1 = (plant_ids == first_train_plant)
    mask_train_plant2 = (plant_ids == second_train_plant)
    tsne = TSNE(
        perplexity=30,
        learning_rate='auto',
        metric='cosine',
        n_iter=100,
        random_state=42,
        initialization='pca',
        n_jobs=-1,
        verbose=True
    )
    embedding_train_plant1 = tsne.fit(X[mask_train_plant2])
    X_stack = np.vstack([W_path, X[test_mask]])
    embedding_stack = embedding_train_plant1.transform(X_stack)
    embedding_W_path = embedding_stack[:W_path.shape[0], :]
    embedding_test = embedding_stack[W_path.shape[0]:, :]

    labels_train_plant1 = labels[mask_train_plant1]
    labels_train_plant2 = labels[mask_train_plant2]
    fig1, ax1 = plt.subplots(figsize=(6, 5))
    for condition in ['Early', 'Control', 'Late']:
        c_mask1 = (labels_train_plant1 == condition)
        if np.any(c_mask1):
            ax1.scatter(embedding_train_plant1[c_mask1, 0], embedding_train_plant1[c_mask1, 1],
                        s=30, alpha=0.7, color=condition_colors[condition], label=f"{condition} ({first_train_plant})")
    ax1.plot(embedding_W_path[:, 0], embedding_W_path[:, 1], 'k*-', label="Principal Path")
    ax1.set_title(f"First Train Plant + Principal Path ({test_plant} held out)")
    ax1.set_ylabel("t-SNE 2")
    ax1.set_xlabel("t-SNE 1")
    ax1.legend()
    ax1.grid(True)
    plt.tight_layout()
    plt.show()
    fig2, ax2 = plt.subplots(figsize=(6, 5))
    for condition in ['Early', 'Control', 'Late']:
        c_mask = (labels_test == condition)
        if np.any(c_mask):
            ax2.scatter(embedding_test[c_mask, 0], embedding_test[c_mask, 1],
                        s=30, alpha=0.5, color=condition_colors[condition], label=f"{condition} (Test)")
    ax2.plot(embedding_W_path[:, 0], embedding_W_path[:, 1], 'k*-', label="Principal Path")
    ax2.set_title("Test Plant + Principal Path")
    ax2.set_xlabel("t-SNE 1")
    ax2.set_ylabel("t-SNE 2")
    ax2.legend()
    ax2.grid(True)
    plt.tight_layout()
    plt.show()
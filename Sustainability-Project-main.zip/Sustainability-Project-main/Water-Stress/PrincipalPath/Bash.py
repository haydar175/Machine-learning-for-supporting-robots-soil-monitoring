import numpy as np
import os
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt
from openTSNE import TSNE
import sys

# Add PrincipalPath package to path
sys.path.append('C:/Users/halhajali/OneDrive - Fondazione Istituto Italiano Tecnologia/Desktop/IIT-UNIBZ/PrincipalPath-master/PrincipalPath-master')
import linear_utilities as lu
import principalpath as pp

# 1. Load data
def load_data(base_path):
    conditions = ["Early", "Control", "Late"]
    plants = ["plant3", "plant0", "plant1"]
   # indices = [198, 199, 187]  
    indices = [0, 1, 3, 2]
    all_data = []
    data_labels = []
    plant_ids = []
    
    for condition in conditions:
        for plant in plants:
            folder_path = os.path.join(base_path, condition, plant)
            if not os.path.exists(folder_path):
                continue
                
            csv_files = [f for f in os.listdir(folder_path) if f.endswith('.csv')]
            
            for file_name in csv_files:
                file_path = os.path.join(folder_path, file_name)
                try:
                    data = np.genfromtxt(file_path, delimiter=',')
                    if data.shape[0] >= 3 and data.shape[1] >= 5:
                        selected_data = data[indices, 3:5]  # Columns 3 and 4
                        flattened = selected_data.flatten()
                        all_data.append(flattened)
                        data_labels.append(condition)
                        plant_ids.append(plant)
                except:
                    continue

    X = np.array(all_data)
    return X, np.array(data_labels), np.array(plant_ids)

# Load and normalize
base_path = "C:/Users/halhajali/OneDrive - Fondazione Istituto Italiano Tecnologia/Desktop/IIT-UNIBZ/Dataset/Water-Stress/"
X, labels, plant_ids = load_data(base_path)
scaler = MinMaxScaler()
X = scaler.fit_transform(X)

# 2. Compute Principal Path
boundary_ids = lu.getMouseSamples2D(X, 2)
NC = 11
waypoint_ids = lu.initMedoids(X, NC, 'kpp', boundary_ids)
waypoint_ids = np.hstack([boundary_ids[0], waypoint_ids, boundary_ids[1]])
W_init = X[waypoint_ids, :]

s_span = np.logspace(5, -5)
s_span = np.hstack([s_span, 0])
models = np.ndarray([s_span.size, NC + 2, X.shape[1]])

for i, s in enumerate(s_span):
    W, u = pp.rkm(X, W_init, s, plot_ax=None)
    W_init = W
    models[i, :, :] = W

ksgm_error = pp.rkm_MS_ksgm(models, s_span, X)
log_evidence = pp.rkm_MS_evidence(models, s_span, X)

best_s_id_ksm = np.argmin(ksgm_error)
best_s_id = np.argmax(log_evidence)

W_ksegment = models[best_s_id_ksm, :, :]
W_evidence = models[best_s_id, :, :]

print(f"Best s (min k-segment error): {s_span[best_s_id_ksm]:.2e}, Error: {ksgm_error[best_s_id_ksm]:.2f}")
print(f"Best s (max evidence): {s_span[best_s_id]:.2e}, Evidence: {log_evidence[best_s_id]:.2f}")

# 3. Fit t-SNE on plant3 only
plant3_mask = (plant_ids == 'plant1')
X_plant3 = X[plant3_mask]

tsne = TSNE(
    perplexity=30,
    learning_rate='auto',
    metric='cosine',
    random_state=42,
    n_iter= 3000,
    initialization='pca',
    n_jobs=-1
)
embedding_plant3 = tsne.fit(X_plant3)

# Transform the global principal path once with plant3's fit
embedding_path_global = embedding_plant3.transform(W_ksegment)

# 4. Plot each plant with both the global path and its own transformed path
#fig, axes = plt.subplots(3, 1, figsize=(5, 5))
#axes = axes.flatten()

plant_list = ["plant3", "plant0", "plant1"]
condition_colors = {'Early': 'blue', 'Control': 'red', 'Late': 'green'}

for plant in plant_list:
    plt.figure(figsize=(6, 5))

    # Get data for current plant
    mask = (plant_ids == plant)
    X_plant = X[mask]
    labels_plant = labels[mask]

    if plant != "plant1":
        embedding_plant = embedding_plant3.transform(X_plant)
        X_concat = np.vstack([X_plant, W_ksegment])
        embedding_concat = embedding_plant3.transform(X_concat)
        plant_embedded = embedding_concat[:len(X_plant)]
        path_embedded = embedding_concat[len(X_plant):]
    else:
        plant_embedded = embedding_plant3
        path_embedded = embedding_path_global

    # Plot data
    for condition in ['Early', 'Control', 'Late']:
        c_mask = (labels_plant == condition)
        if np.any(c_mask):
            plt.scatter(
                plant_embedded[c_mask, 0],
                plant_embedded[c_mask, 1],
                s=30, alpha=0.7,
                color=condition_colors[condition],
                label=condition
            )

    plt.plot(path_embedded[:, 0], path_embedded[:, 1], 'k*-', label="Principal Path")

    plt.xlabel("t-SNE 1")
    plt.ylabel("t-SNE 2")
    plt.title(f"{plant} with Principal Path")
    plt.legend()
    plt.tight_layout()
    plt.show()
